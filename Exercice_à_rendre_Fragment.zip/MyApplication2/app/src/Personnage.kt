package src

class Personnage {
}