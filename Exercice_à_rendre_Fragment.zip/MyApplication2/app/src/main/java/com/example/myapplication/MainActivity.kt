import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.ListFragment
import com.example.myapplication.R


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val listFragment = ListFragment()

        supportFragmentManager
            .beginTransaction()
            .replace(R.id.container1, listFragment)
            .replace(R.id.container2, listFragment)
            .commitAllowingStateLoss()
    }
}
