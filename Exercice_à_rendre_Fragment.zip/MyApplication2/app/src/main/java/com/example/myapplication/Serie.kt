import android.app.Fragment
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.bundleOf
import com.example.myapplication.R

// Création d'une classe modèle pour représenter une série
data class Serie(val id: Int, val title: String, val description: String, val characters: List<String>, val episodes: List<String>)

// Fonction pour générer des fausses données de séries
fun generateFakeSeries(): List<Serie> {
    val fakeSeries = mutableListOf<Serie>()
    for (i in 1..10) {
        fakeSeries.add(
            Serie(
                id = i,
                title = "Série $i",
                description = "Description de la série $i.",
                characters = (1..5).map { "Personnage $it" },
                episodes = (1..10).map { "Épisode $it" }
            )
        )
    }
    return fakeSeries
}

// Fragment pour afficher la liste des séries
class SeriesListFragment : Fragment() {
    // ... (Mettre en place l'UI pour la liste)
}

// Fragment pour afficher les détails d'une série
class SeriesDetailsFragment : Fragment() {
    // ... (Mettre en place l'UI pour les détails)
}

