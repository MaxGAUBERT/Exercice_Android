package com.example.actit3emecours

data class Product(
    val name: String,
    val brand: String,
    val nutriScore: NutriScore,
    val barcode: String,
    val thumbnail: String,
    val quantity: String,
    val countries: List<String>,
    val ingredients: List<String>,
    val allergens: List<String>,
    val additives: List<String>,
)


enum class NutriScore(val label: String) {
    A("A"), B("B"), C("C"), D("D"), E("E"), Unknown("")
}



fun generateFakeProduct() = Product(

    name = "ROBIN BOUCHET PAS CHER ",
    brand = "Cassegrain",
    nutriScore = NutriScore.A,
    barcode = "3083680085304",
    thumbnail = "https://s12937.pcdn.co/wp-content/uploads/2019/11/Robin-Bouchet-519x400.jpg",
    quantity = "400g",
    countries = listOf("France", "Japon", "Suisse"),
    ingredients = listOf(
        "Petits pois 66%",
        "Eau",
        "Garniture 2,8% (salade, oignon grelot)",
        "Sucre",
        "Sel",
        "ArÃ´me naturel"
    ),
    allergens = emptyList(),
    additives = emptyList(),
)